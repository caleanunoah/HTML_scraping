class QuoteLocators:
    AUTHOR = 'small.author'
    CONTENT = 'span.text'
    TAGS = 'div.tags a.tag'
