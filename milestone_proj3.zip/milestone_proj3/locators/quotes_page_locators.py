class QuotesPageLocators:
    """
    Class for accessing all parent div containers on a page
    """
    QUOTE = 'div.quote'
